/*
 ============================================================================
 Name        : Client_esonero.c
 Author      : Ciuffreda Matteo Pio 758182 - Cassibba Claudio Biagio 758180
 Version     :
 Copyright   :
 Description : Server
 ============================================================================
 */
#include "protocol.h"

//function
void ClearWinSock();

#define MAX 30

//Function prototypes
int add(int first, int second);
int Subtraction(int first, int second);
int Multiplication(int first, int second);
double Division(int first, int second);

int main(int argc, char *argv[]) {
    //controllo sul numero di porta
    int port;

    if (argc > 1) {
      port = atoi(argv[1]);
    } else {
      port = PROTOPORT;
    }

    #if defined WIN32
    	//Initialize Winsock
		WSADATA wsaData;
		WORD version_requested;

		version_requested = MAKEWORD(2,2);
		int result = WSAStartup(version_requested, &wsaData);

		if (result != 0) {
			printf("Error at WSAStartup()\n");
			return 0;
		}
    #endif

    //Create Welcome socket
    int MySocket;

    MySocket = socket(PF_INET, SOCK_STREAM, IPPROTO_TCP);

    if(MySocket < 0){
        printf("Socket creation failed.\n");
        ClearWinSock();
        return -1;
    }

    //Set connection settings
    struct sockaddr_in sad;
    memset(&sad, 0, sizeof(sad));// ensures that extra bytes contain 0

    sad.sin_family = AF_INET;
    sad.sin_addr.s_addr = inet_addr("127.0.0.1"); //inet_addr: converts the passed number to binary notation
    sad.sin_port = htons(port); //htons:  translates a short integer from host byte order to network byte order

    //funzione bind(): associates an address with the socket so that it can be contacted by a client
    if (bind(MySocket, (struct sockaddr*) &sad, sizeof(sad)) <0) {
        printf("bind() failed.\n");
        closesocket(MySocket);
        ClearWinSock();
        return -1;
    }

    //funzione listen(): sets the socket to a listening state, waiting for a connection request
    if (listen (MySocket, QLEN) < 0) {
        printf("listen() failed.\n");
        closesocket(MySocket);
        ClearWinSock();
        return -1;
    }

    //Accept new connection
    struct sockaddr_in cad; //Structure for the client address
    int clientSocket;       //Socket descriptor for the client
    int clientLen;          //Size of the client address

    printf("Waiting for a client to connect...\n");

    while (1) {
        clientLen = sizeof(cad); //Set the size of the client address

        //funzione accept(): Allows an inbound connection attempt on a socket
        if ((clientSocket = accept(MySocket, (struct sockaddr*) &cad, &clientLen)) < 0) {
          printf("accept() failed.\n");
          closesocket(MySocket);
          ClearWinSock();
          return -1;
        }

        //ClientSocket is connected to a client
        printf("Connection established with : %s:%d\n\n", inet_ntoa(cad.sin_addr), sad.sin_port); //inet_ntoa: coverte da binario a notazione puntata

        //Send a connection confirmation message
        char* s="Connection established.";
        send(clientSocket, s, strlen(s), 0);

        //String that will be received by the client
        char operation[BUFFERSIZE];

        //String for operator
        char operator = '\0';

	do {

		//Receives the string from the client
		if(recv(clientSocket, operation, BUFFERSIZE-1, 0) <= 0){
			printf("Reception Failed.");
			closesocket(clientSocket);
			break;
		}

		//Variables to hold the remaining parts of the string
		char* token = NULL;
		char operator;
		int first_num;
		int second_num;
		token = strtok(operation," ");
		operator = token[0];
		if (operator != '=')
		{
			token = strtok(NULL," ");
			first_num = atoi(token);
			token = strtok(NULL," ");
			second_num = atoi(token);

			double result = 0; //Contains the result of the operation
			int control = 0; //Error checking
			char error_string[] = "Wrong operator or division by 0. Try again.";

			switch (operator)
			{
				case '+':
					result = add(first_num, second_num);
					break;
				case '-':
					result = Subtraction(first_num, second_num);
					break;
				case '*':
					result = Multiplication(first_num, second_num);
					break;
				case '/':
					if(second_num == 0) {
						control = 1;
					}
					result = Division(first_num, second_num);
					break;
				default:
					control = 1;
					break;
			}


			if(control == 0) {

				//Send the result of the operation to the client
				char string_result[BUFFERSIZE];
				sprintf(string_result, "%.2f", result);
				send(clientSocket, string_result, strlen(string_result), 0);
				printf("Result sent.\n");
			} else {

				//Send the error string
				send(clientSocket, error_string, strlen(error_string), 0);
				printf("\nError sent.\n\n");
			}

		  }

		} while (operator != '=');

		closesocket(clientSocket);

		printf( "\nWaiting for a client to connect...\n");
	}
}

//Return the result of the sum
int add(int first, int second) {
  return first + second;
}

//Return the result of the subtraction
int Subtraction(int first, int second) {
  return first - second;
}

//Return the result of the multiplication
int Multiplication(int first, int second) {
  return first * second;
}

//Return the result of the division
double Division(int first, int second) {
  return (double) first / second;
}

//function
void ClearWinSock() {
	#if defined WIN32
	WSACleanup();
	#endif
}
