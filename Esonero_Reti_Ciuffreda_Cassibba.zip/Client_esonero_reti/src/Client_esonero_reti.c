/*
 ============================================================================
 Name        : Client_esonero.c
 Author      : Ciuffreda Matteo Pio 758182 - Cassibba Claudio Biagio 758180
 Version     :
 Copyright   :
 Description : Client
 ============================================================================
 */

#include "protocol.h"

//function
void ClearWinSock();

int main() {

	//Create an element of type WSADATA:
    #if defined WIN32
      WSADATA wsaData;
      WORD version_requested;

      version_requested = MAKEWORD(2,2);
      /*Specifies the required windows socket version and
          retrieves socket implementation details
          specific windows*/
      int result = WSAStartup(version_requested, &wsaData);

        if (result != 0) {
            printf("Error at WSAStartup()\n");
            return -1;
        }
    #endif

    //Create welcome socket
    int Csocket;
    Csocket = socket(PF_INET, SOCK_STREAM, IPPROTO_TCP);
        if (Csocket < 0) {
            printf("Socket creation failed.\n");
            closesocket(Csocket);
            ClearWinSock();
            return -1;
        }

      // Creating an element of type sockaddr_in to reference the socket to connect to
    struct sockaddr_in sad;
    sad.sin_family = AF_INET;	//Ensures that extra bytes contain 0 sad.sin_family = AF_INET;
    sad.sin_addr.s_addr = inet_addr("127.0.0.1"); //Server IP
    sad.sin_port = htons(PROTOPORT); //Convert a number from local computer format a that of the network


    //connect() function: Establishes a connection to a specified socket (through an address)
    if (connect(Csocket, (struct sockaddr *) &sad, sizeof(sad)) < 0) {
        printf( "Failed to connect.\n" );
        closesocket(Csocket);
        ClearWinSock();
        return -1;
    }

    // receive from server
    char verifica[BUFFERSIZE];

      if (recv(Csocket, verifica, BUFFERSIZE - 1, 0) <= 0) {
          printf("\nrecv() failed or connection closed prematurely\n");
          closesocket(Csocket);
          ClearWinSock();
          return -1;
      }
      else
      {
          printf("Received: %s\n\n", verifica);
      }

      char stringA[BUFFERSIZE] = "";
      //get data from user
      do {
          puts("Enter the math formula: ");
          fgets(stringA, BUFFERSIZE, stdin);
       //Send data to a connected socket
          if (stringA[0] == '='){
        	  	send(Csocket, stringA, strlen(stringA), 0);
                closesocket(Csocket);
				ClearWinSock();
				return 0;
          }
          if (send(Csocket, stringA, strlen(stringA), 0) != strlen(stringA)){
              printf("\nsend() failed\n");
              closesocket(Csocket);
              ClearWinSock();
              return -1;
          }

        memset(&stringA, '\0', BUFFERSIZE);
        char result[BUFFERSIZE];

        //Receives data from a connected socket
        if (recv(Csocket, result, BUFFERSIZE - 1, 0) <= 0) {
          printf("\nrecv() failed or connection closed prematurely\n");
          closesocket(Csocket);
          ClearWinSock();
            return 0;
        }
        printf("The result is: %s\n\n", result);
        memset(&result, '\0', BUFFERSIZE);
      } while (stringA[0] != '=');

      system("PAUSE");
      //close the connection
      closesocket(Csocket);
      ClearWinSock();
      return(0);
} //main end

//function
void ClearWinSock() {
    #if defined WIN32
    WSACleanup();
    #endif
}
